"""
Equipo: PostgresandoesoSQLazos
Integrantes:
Adrian Aguilera Moreno
Diego Martínez Calzada
Israel Hernández Dorantes
Marco Antonio Rivera Silva
Kevin Jair Torres Valencia
"""

import pandas as pd

empleados = pd.read_csv("Empleado.csv")
plantas = pd.read_csv("Planta.csv")
viveros = pd.read_csv("Vivero.csv")

# Metodo que muestra el menu general elaborado para la base de datos en la terminal.
def menuPrincipal():
    '''
    Menu principal
    '''
    seguir = True
    print("********** Bienvenido a la Base de Datos **********")
    while seguir:
        try:
            print("-> Selecciona la entidad que quieres administrar:")
            print("1. Empleados")
            print("2. Plantas")
            print("3. Viveros")
            print("4. Cantidades de cada entidad")
            print("5. Salir")
            print("Opcion: ")
            opcion = (int(input()))
            if opcion == 1:
                menuEmpleados()
            elif opcion == 2:
                menuPlantas()
            elif opcion == 3:
                menuViveros()
            elif opcion == 4:
                print(len(empleados))
                print("Tenemos " + str(len(empleados)) + " empleados, " + str(len(plantas)) + " plantas y " + str(len(viveros)) + " viveros.")
            elif opcion == 5:
                print("Muchas gracias, hasta luego!")
                seguir = False
            else:
                print("Por favor introduce una opcion valida")
        except:
            print("\nPor favor introduce un numero.")

#======================   Metodos Empleados     ================================

# Metodo que muestra el menu elaborado para los empleados en la terminal.
def menuEmpleados():
    """Metodo que muestra el menu elaborado para los empleados en la terminal."""
    seguir = True
    print("***** Bienvenido a la Base de Datos para Empleados *****")
    while seguir:
        try:
            empleados = pd.read_csv("Empleado.csv")
            print("\n-> Selecciona la accion que deseas realizar")
            print("1. Ver Empleados")
            print("2. Agregar Empleados")
            print("3. Editar Empleados")
            print("4. Eliminar Empleados")
            print("5. Buscar Empleado por Id")
            print("6. Atras")
            opcion = (int(input()))
            if opcion == 1:
                print(empleados)
            elif opcion == 2:
                empleados = pd.read_csv("Empleado.csv")
                agregarEmpleado()
            elif opcion == 3:
                empleados = pd.read_csv("Empleado.csv")
                editarEmpleado()
            elif opcion == 4:
                empleados = pd.read_csv("Empleado.csv")
                eliminarEmpleado()
            elif opcion == 5:
                empleados = pd.read_csv("Empleado.csv")
                buscarEmpleado()
            elif opcion == 6:
                seguir = False
            else:
                print("Por favor introduce una opcion valida")
        except:
            print("Por favor introduce un numero.")

# Metodo que nos permite agregar un empleado en el archivo SVC.
def agregarEmpleado():
    """Metodo que nos permite agregar un empleado en el archivo SVC."""
    empleados = pd.read_csv("Empleado.csv")
    id = crearIdEmpleado()
    nombre = input("\n- Introduce el nombre del empleado que deseas agregar: ")
    correo = input("- Introduce el correo del empleado que deseas agregar (En caso se tener varios ingresalos separados por espacios): ")
    telefono = input("- Introduce el telefono del empleado que deseas agregar (En caso se tener varios ingresalos separados por espacios): ")
    direccion = input("- Introduce la direccion del empleado que deseas agregar: ")
    salario = input("- Introduce el salario del empleado que deseas agregar: ")
    fechaNac = input("- Introduce la fecha de nacimiento del empleado que deseas agregar (Formato DD-MM-AAAA): ")
    puesto = input("- Introduce el puesto del empleado que deseas agregar: ")
    nuevoEmpleado = pd.Series([id, nombre, correo, telefono, direccion, salario, fechaNac, puesto], index=["IdEmpleado","Nombre","CorreoElectronico","Telefono","Direccion","Salario","FechaNacim","PuestoTrabajo"])
    print(nuevoEmpleado)
    resultado = pd.concat([empleados, nuevoEmpleado.to_frame().T], ignore_index=False)
    print(resultado)
    resultado.to_csv("Empleado.csv", index=False)
    print("Empleado agregado con exito.")

# Metodo que define el Id unico para cada empleado.
def crearIdEmpleado():
    """Metodo que define el Id unico para cada empleado."""
    empleados = pd.read_csv("Empleado.csv")
    id = empleados.iloc[-1,0]
    nuevoId = id[0] + str(int(id[1:])+1)
    return nuevoId

#  Metodo que verifica si existe un empleado dentro del archivo SVC, mediante su Id.
def existeEmpleado(id):
    """Metodo que verifica si existe un empleado dentro del archivo SVC, mediante su Id."""
    empleados = pd.read_csv("Empleado.csv")
    for i in range(0, len(empleados)):
        if(empleados.iloc[i,0] == id):
            return True

    return False

# Metodo que devuelve el numero de reglon donde se encuentra el Id del empleado del archivo SVC.
def renglonEmpleado(id):
    """Metodo que devuelve el numero de reglon donde se encuentra el Id del empleado del archivo SVC."""
    empleados = pd.read_csv("Empleado.csv")
    for i in range(0, len(empleados)):
        if(empleados.iloc[i,0] == id):
            return i
    return -1

# Metodo que nos permite modificar los datos de un empleado, identificandolo por su Id.
def editarEmpleado():
    """Metodo que nos permite modificar los datos de un empleado, identificandolo por su Id."""
    id = input("\n-> Introduce el Id del empleado que necesitas editar: ")
    if(existeEmpleado(id) == True):
        seguir = True
        while seguir:
            try:
                empleados = pd.read_csv("Empleado.csv")
                print("\n- Selecciona el dato que deseas editar:")
                print("1. Nombre")
                print("2. Correo Electronico")
                print("3. Telefono")
                print("4. Direccion")
                print("5. Salario")
                print("6. Fecha de Nacimiento")
                print("7. Puesto de Trabajo")
                print("Opcion: ")
                opcion = (int(input()))
                if opcion == 1:
                    nuevo = input("- Introduce el nuevo nombre del empleado: ")
                    empleados.iloc[renglonEmpleado(id),1] = nuevo
                    seguir = False
                elif opcion == 2:
                    nuevo = input("- Introduce el (o los) nuevo(s) correo(s) del empleado: ")
                    empleados.iloc[renglonEmpleado(id),2] = nuevo
                    seguir = False
                elif opcion == 3:
                    nuevo = input("- Introduce el (o los) nuevo(s) telefono(s) del empleado: ")
                    empleados.iloc[renglonEmpleado(id),3] = nuevo
                    seguir = False
                elif opcion == 4:
                    nuevo = input("- Introduce la nueva Direccion del empleado: ")
                    empleados.iloc[renglonEmpleado(id),4] = nuevo
                    seguir = False
                elif opcion == 5:
                    nuevo = input("- Introduce el nuevo salario del empleado: ")
                    empleados.iloc[renglonEmpleado(id),5] = nuevo
                    seguir = False
                elif opcion == 6:
                    nuevo = input("- Introduce la nueva Fecha de Nacimiento del empleado: ")
                    empleados.iloc[renglonEmpleado(id),6] = nuevo
                    seguir = False
                elif opcion == 7:
                    nuevo = input("- Introduce el nuevo Puesto de Trabajo del empleado: ")
                    empleados.iloc[renglonEmpleado(id),7] = nuevo
                    seguir = False
                else:
                    print("Por favor introduce una opcion valida")
            except:
                print("Por favor introduce un numero")
        empleados.to_csv("Empleado.csv", index=False)
    else:
        print("No existe ningun empleado con ese Id, regresando al menu...")

# Metodo que nos permite eliminar un empleado, identificandolo por su Id.
def eliminarEmpleado():
    """Metodo que nos permite eliminar un empleado, identificandolo por su Id."""
    empleados = pd.read_csv("Empleado.csv")
    id = input("\n-> Introduce el Id del empleado que necesitas eliminar: ")
    if(existeEmpleado(id) == True):
        resultado = empleados.drop(empleados.index[renglonEmpleado(id)])
        print("Borrado completado.")
        resultado.to_csv("Empleado.csv", index=False)
    else:
        print("No existe ningun empleado con ese Id, regresando al menu...")

# Metodo que nos permite buscar un vivero, identificandolo por su Id.
def buscarEmpleado():
    """Metodo que nos permite buscar un vivero, identificandolo por su Id."""
    empleados = pd.read_csv("Empleado.csv")
    id = input("\n-> Introduce el Id del empleado que necesitas buscar: ")
    if(existeEmpleado(id) == True):
        print("Resultado de busqueda: ")
        print(empleados.loc[[renglonEmpleado(id)]])
    else:
        print("No existe un empleado con ese Id.")


#======================   Metodos Plantas     ==================================

# Metodo que muestra el menu elaborado para los plantas en la terminal.
def menuPlantas():
    """Metodo que muestra el menu elaborado para los plantas en la terminal."""
    seguir = True
    print("***** Bienvenido a la Base de Datos para Plantas *****")
    while seguir:
        try:
            plantas = pd.read_csv("Planta.csv")
            print("\n-> Selecciona la accion que deseas realizar")
            print("1. Ver todas las Plantas")
            print("2. Agregar Planta")
            print("3. Editar Planta")
            print("4. Eliminar Planta")
            print("5. Buscar planta por Id")
            print("6. Atras")
            print("Opcion: ")
            opcion = (int(input()))
            if opcion == 1:
                print(plantas)
            elif opcion == 2:
                agregarPlanta()
            elif opcion == 3:
                editarPlanta()
            elif opcion == 4:
                eliminarPlanta()
            elif opcion == 5:
                buscarPlanta()
            elif opcion == 6:
                seguir = False
            else:
                print("Por favor introduce una opcion valida")
        except:
            print("Por favor introduce un numero.")

# Metodo que nos permite agregar una planta en el archivo SVC.
def agregarPlanta():
    """Metodo que nos permite agregar una planta en el archivo SVC."""
    plantas = pd.read_csv("Planta.csv")
    id = crearIdPlanta()
    nombre = input("\n- Introduce el nombre de la planta que deseas agregar: ")
    genero = input("- Introduce el genero de la planta: ")
    precio = input("- Introduce el precio de la planta: ")
    fechaGerminacion = input("- Introduce la fecha de germinacion de la planta (Formato DD-MM-AAAA): ")
    tipoPlanta = input("- Introduce el tipo de planta (si es de sol, sombra o resolana): ")
    tiempoDeRiega = input("- Introduce el tiempo de cada cuanto se riega la planta: ")
    cuidadoBasico = input("- Introduce el tipo de cuidado que necesita la planta: (En caso se tener varios ingresalos separados por espacios): ")
    tipoDeSutrato = input("- Introduce el tipo de sustrato que requiere la planta: ")
    areaVivero = input("- Introduce el area de vivero a la que pertenece la planta: ")
    cantidad = input("- Introduce la cantidad de plantas que tiene esta especie: ")
    nuevaPlanta = pd.Series([id, nombre, genero, precio, fechaGerminacion, tipoPlanta, tiempoDeRiega, cuidadoBasico, tipoDeSutrato, areaVivero, cantidad], index=["IdPlanta","Nombre","Genero","Precio","FechaGerminacion","TipoPlanta","TiempoRegar","CuidadoBasico","TipoSustrato", "TipoAreaVivero", "Cantidad"])
    print(nuevaPlanta)
    resultado = pd.concat([plantas, nuevaPlanta.to_frame().T], ignore_index=False)
    print(resultado)
    resultado.to_csv("Planta.csv", index=False)
    print("Planta agregada con exito.")

# Metodo que define el Id unico para cada planta.
def crearIdPlanta():
    """etodo que define el Id unico para cada planta."""
    plantas = pd.read_csv("Planta.csv")
    id = plantas.iloc[-1,0]
    nuevoId = id[0] + str(int(id[1:])+1)
    return nuevoId

# Metodo que verifica si existe una planta dentro del archivo SVC, mediante su Id.
def existePlanta(id):
    """Metodo que verifica si existe una planta dentro del archivo SVC, mediante su Id."""
    plantas = pd.read_csv("Planta.csv")
    for i in range(0, len(plantas)):
        if(plantas.iloc[i,0] == id):
            return True

    return False

# Metodo que devuelve el numero de reglon donde se encuentra el Id de la planta del archivo SVC.
def renglonPlanta(id):
    """Metodo que devuelve el numero de reglon donde se encuentra el Id de la planta del archivo SVC."""
    plantas = pd.read_csv("Planta.csv")
    for i in range(0, len(plantas)):
        if(plantas.iloc[i,0] == id):
            return i
    return -1

# Metodo que nos permite modificar los datos de una planta, identificandolo por su Id.
def editarPlanta():
    """Metodo que nos permite modificar los datos de una planta, identificandolo por su Id."""
    id = input("\n-> Introduce el Id de la planta que necesitas editar: ")
    if(existePlanta(id) == True):
        seguir = True
        while seguir:
            try:
                plantas = pd.read_csv("Planta.csv")
                print("\n- Selecciona el dato que deseas editar:")
                print("1. Nombre")
                print("2. Genero")
                print("3. Precio")
                print("4. Fecha de Germinacion")
                print("5. Tipo de Planta")
                print("6. Tiempo de Riega")
                print("7. Cuidado Basico")
                print("8. Tipo de Sustrato")
                print("9. Area de Vivero")
                print("Opcion: ")
                opcion = (int(input()))
                if opcion == 1:
                    nuevo = input("- Introduce el nuevo Nombre de la planta: ")
                    plantas.iloc[renglonPlanta(id),1] = nuevo
                    seguir = False
                elif opcion == 2:
                    nuevo = input("- Introduce el nuevo Genero de la planta: ")
                    plantas.iloc[renglonPlanta(id),2] = nuevo
                    seguir = False
                elif opcion == 3:
                    nuevo = input("- Introduce el nuevo Precio de la planta: ")
                    plantas.iloc[renglonPlanta(id),3] = nuevo
                    seguir = False
                elif opcion == 4:
                    nuevo = input("- Introduce la nueva Fecha de Germinacion de la planta: ")
                    plantas.iloc[renglonPlanta(id),4] = nuevo
                    seguir = False
                elif opcion == 5:
                    nuevo = input("- Introduce el nuevo Tipo de planta: ")
                    plantas.iloc[renglonPlanta(id),5] = nuevo
                    seguir = False
                elif opcion == 6:
                    nuevo = input("- Introduce el nuevo Tiempo de Riega de la planta: ")
                    plantas.iloc[renglonPlanta(id),6] = nuevo
                    seguir = False
                elif opcion == 7:
                    nuevo = input("- Introduce el o los nuevos Cuidados Basicos de la planta: ")
                    plantas.iloc[renglonPlanta(id),7] = nuevo
                    seguir = False
                elif opcion == 8:
                    nuevo = input("- Introduce el nuevo Tipo de Sustrato de la planta: ")
                    plantas.iloc[renglonPlanta(id),8] = nuevo
                    seguir = False
                elif opcion == 9:
                    nuevo = input("- Introduce el Area de Vivero a la que pertence la planta: ")
                    plantas.iloc[renglonPlanta(id),9] = nuevo
                    seguir = False
                else:
                    print("Por favor introduce una opcion valida")
            except:
                print("Por favor introduce un numero")
        plantas.to_csv("Planta.csv", index=False)
    else:
        print("No existe ninguna planta con ese Id, regresando al menu...")

# Metodo que nos permite eliminar una planta, identificandolo por su Id.
def eliminarPlanta():
    """Metodo que nos permite eliminar una planta, identificandolo por su Id."""
    plantas = pd.read_csv("Planta.csv")
    id = input("\n-> Introduce el Id de la planta que necesitas eliminar: ")
    if(existePlanta(id) == True):
        resultado = plantas.drop(plantas.index[renglonPlanta(id)])
        print("Borrado completado.")
        resultado.to_csv("Planta.csv", index=False)
    else:
        print("No existe ninguna planta con ese Id, regresando al menu...")

# Metodo que nos permite buscar una planta, identificandolo por su Id.
def buscarPlanta():
    """Metodo que nos permite buscar una planta, identificandolo por su Id."""
    plantas = pd.read_csv("Planta.csv")
    id = input("\n-> Introduce el Id de la planta que necesitas buscar: ")
    if(existePlanta(id) == True):
        print("Resultado de busqueda: ")
        print(plantas.loc[[renglonPlanta(id)]])
    else:
        print("No existe una planta con ese Id.")

#======================   Metodos Viveros     ==================================

# Metodo que muestra el menu elaborado para los viveros en la terminal.
def menuViveros():
    """Metodo que muestra el menu elaborado para los viveros en la terminal."""
    seguir = True
    print("\n***** Bienvenido a la Base de Datos para Viveros *****")
    while seguir:
        try:
            viveros = pd.read_csv("Vivero.csv")
            print("\n-> Selecciona la accion que deseas realizar")
            print("1. Ver todas los Viveros")
            print("2. Agregar Vivero")
            print("3. Editar Vivero")
            print("4. Eliminar Vivero")
            print("5. Buscar Vivero por id")
            print("6. Atras")
            print("Opcion: ")
            opcion = (int(input()))
            if opcion == 1:
                print(viveros)
            elif opcion == 2:
                agregarVivero()
            elif opcion == 3:
                editarVivero()
            elif opcion == 4:
                eliminarVivero()
            elif opcion == 5:
                buscarVivero()
            elif opcion == 6:
                seguir = False
            else:
                print("Por favor introduce una opcion valida")
        except:
            print("Por favor introduce un numero.")

# Metodo que nos permite agregar un vivero en el archivo SVC.
def agregarVivero():
    """Metodo que nos permite agregar un vivero en el archivo SVC."""
    viveros = pd.read_csv("Vivero.csv")
    id = crearIdVivero()
    nombre = input("\n- Introduce el nombre del vivero que deseas agregar: ")
    direccion = input("- Introduce la direccion del vivero que deseas agregar: ")
    area = input("- Introduce la(s) area(a) con las que cuenta: ")
    telefono = input("- Introduce el telefono del vivero que deseas agregar: \n (En caso se tener varios ingresalos separados por espacios) ")
    fechaApertura = input("- Introduce la fecha de apertura del vivero: \n (Formato DD-MM-AAAA) ")
    nuevoVivero = pd.Series([id, nombre, direccion, area, telefono, fechaApertura], index=["IdVivero","Nombre","Direccion","Area","Telefono","FechaApertura"])
    print(nuevoVivero)
    resultado = pd.concat([viveros, nuevoVivero.to_frame().T], ignore_index=False)
    print(resultado)
    resultado.to_csv("Vivero.csv", index=False)
    print("Vivero agregado con exito.")

# Metodo que define el Id unico para cada vivero.
def crearIdVivero():
    """Metodo que define el Id unico para cada vivero."""
    viveros = pd.read_csv("Vivero.csv")
    id = viveros.iloc[-1,0]
    nuevoId = id[0] + str(int(id[1:])+1)
    return nuevoId

# Metodo que verifica si existe un vivero dentro del archivo SVC, mediante su Id.
def existeVivero(id):
    """Metodo que verifica si existe un vivero dentro del archivo SVC, mediante su Id."""
    viveros = pd.read_csv("Vivero.csv")
    for i in range(0, len(viveros)):
        if(viveros.iloc[i,0] == id):
            return True

    return False

# Metodo que devuelve el numero de reglon donde se encuentra el Id del vivero del archivo SVC.
def renglonVivero(id):
    """Metodo que devuelve el numero de reglon donde se encuentra el Id del vivero del archivo SVC."""
    viveros = pd.read_csv("Vivero.csv")
    for i in range(0, len(viveros)):
        if(viveros.iloc[i,0] == id):
            return i
    return -1

# Metodo que nos permite modificar los datos de un vivero, identificandolo por su Id.
def editarVivero():
    """Metodo que nos permite modificar los datos de un vivero, identificandolo por su Id."""
    id = input("\n-> Introduce el Id del vivero que necesitas editar: ")
    if(existeVivero(id) == True):
        seguir = True
        while seguir:
            try:
                viveros = pd.read_csv("Vivero.csv")
                print("\n- Selecciona el dato que deseas editar:")
                print("1. Nombre")
                print("2. Direccion")
                print("3. Area(s) que tiene")
                print("4. Telefono")
                print("5. Fecha de Apertura")
                print("Opcion: ")
                opcion = (int(input()))
                if opcion == 1:
                    nuevo = input("- Introduce el nuevo Nombre del vivero: ")
                    viveros.iloc[renglonVivero(id),1] = nuevo
                    seguir = False
                elif opcion == 2:
                    nuevo = input("- Introduce la nueva Direccion del vivero: ")
                    viveros.iloc[renglonVivero(id),2] = nuevo
                    seguir = False
                elif opcion == 3:
                    nuevo = input("- Introduce la nueva Area del vivero: ")
                    viveros.iloc[renglonVivero(id),3] = nuevo
                    seguir = False
                elif opcion == 4:
                    nuevo = input("- Introduce el nuevo Telefono del vivero: ")
                    viveros.iloc[renglonVivero(id),4] = nuevo
                    seguir = False
                elif opcion == 5:
                    nuevo = input("- Introduce la nueva Fecha de Apertura del vivero: ")
                    viveros.iloc[renglonVivero(id),5] = nuevo
                    seguir = False
                else:
                    print("Por favor introduce una opcion valida")
            except:
                print("Por favor introduce un numero")
        viveros.to_csv("Vivero.csv", index=False)
    else:
        print("No existe ninguna planta con ese Id, regresando al menu...")

# Metodo que nos permite eliminar un vivero, identificandolo por su Id.
def eliminarVivero():
    """Metodo que nos permite eliminar un vivero, identificandolo por su Id."""
    viveros = pd.read_csv("Vivero.csv")
    id = input("\n-> Introduce el Id del vivero que necesitas eliminar: ")
    if(existeVivero(id) == True):
        resultado = viveros.drop(viveros.index[renglonVivero(id)])
        print("Borrado completado.")
        resultado.to_csv("Vivero.csv", index=False)
    else:
        print("No existe ningun vivero con ese Id, regresando al menu...")

# Metodo que nos permite buscar un vivero, identificandolo por su Id.
def buscarVivero():
    """Metodo que nos permite buscar un vivero, identificandolo por su Id."""
    viveros = pd.read_csv("Vivero.csv")
    id = input("\n-> Introduce el Id del vivero que necesitas buscar: ")
    if(existeVivero(id) == True):
        print("Resultado de busqueda: ")
        print(viveros.loc[[renglonVivero(id)]])
    else:
        print("No existe un vivero con ese Id.")

menuPrincipal()
