/****************************************
Lenguaje para definición de datos (DDL)
****************************************/

--Creación de una tabla simple, sin restricciones
create table cliente(
correo varchar(100),
nombre varchar(100),
paterno varchar(100),
materno varchar(100),
direccion varchar(100),
fecha date
);

--Probar una inserción en esta tabla, enviando todos los valores en orden
insert into cliente values('juan@gmail.com.mx','JUAN MANUEL','PÉREZ','RÍOS',
						   'FAISANES 43 EDOMEX','1985-04-26');
select * from cliente;
--Inserción con los valores desordenados
insert into cliente values('PATRICIA','patyhs@gmail.com.mx','HERNÁNDEZ','BUGAMBILIAS 85 CDMX',
						   'SÁNCHEZ','1980-11-03');
--Inserción con valores desordenados, solución al problema anterior
insert into cliente(nombre,correo,paterno,direccion,materno,fecha) 
values('PATRICIA','patyhs@gmail.com.mx','HERNÁNDEZ','BUGAMBILIAS 85 CDMX','SÁNCHEZ','1980-11-03');

--Insertar solo un subconjunto de valores (solo si la tabla lo permite):
insert into cliente values('luisahdz@hotmail.com','1995-06-14');

----Insertar solo un subconjunto de valores (solo si la tabla lo permite), solución
insert into cliente(correo,fecha) values('luisahdz@hotmail.com','1995-06-14');
select * from cliente;

--Vaciar una tabla con delete
delete from cliente;

--Borrar una tabla
drop table cliente;

--Agregar una tabla con restricciones de llave primaria (al menos)
create table cliente(
correo varchar(100) primary key,
nombre varchar(100),
paterno varchar(100),
materno varchar(100),
direccion varchar(100),
fecha date
);

--Intentar insertar más de una vez la siguiente tupla:
insert into cliente(nombre,correo,paterno,direccion,materno,fecha) 
values('PATRICIA','patyhs@gmail.com.mx','HERNÁNDEZ','BUGAMBILIAS 85 CDMX','SÁNCHEZ','1980-11-03');
select * from cliente;
--¿Qué fue lo que pasó?

--Insertar solo un subconjunto de valores (solo si la tabla lo permite):
insert into cliente values('carlosamaro@gmail.com','1985-03-24');
insert into cliente(nombre,paterno,materno) values('LAURA','FRÍAS','GONZÁLEZ');

--Borrar la tabla
drop table cliente;

--¿Qué pasa si la tabla tiene una llave primaria compuesta?
create table pelicula(
titulo varchar(100) primary key,
año int primary key,
genero varchar(100),
pais varchar(100)
);

--Solución:
create table pelicula(
titulo varchar(100),
año int,
genero varchar(100),
pais varchar(100),
primary key(titulo,año)
);

insert into pelicula values('King kong',1993,'Ciencia Ficción','EU');
insert into pelicula values('King kong',2005,'Ciencia Ficción','EU');

select concat(titulo,año),genero,pais
from pelicula;

select concat(titulo,año,genero,pais)
from pelicula;

--Borrar la tabla
drop table pelicula;

--Llave primaria compuesta, otra forma (recomendada)
create table pelicula(
titulo varchar(100),
año int,
genero varchar(100),
pais varchar(100),
constraint pkpelicula primary key(titulo,año)
);

insert into pelicula values('King kong',1993,'Ciencia Ficción','EU');
insert into pelicula values('King kong',2005,'Ciencia Ficción','EU');
select * from pelicula;
--Borrar una restricción de llave primaria
alter table pelicula drop constraint pkpelicula;

--Volver a insertar las filas iniciales
--Volver a agregar la restricción de llave primaria (se debe garantizar la unicidad)
alter table pelicula add constraint pkpelicula primary key(titulo,año);

--Resolver el problema: 
--Borrar registros duplicados (solo en PostgreSQL)
delete from pelicula where ctid not in (select max(ctid) from pelicula group by pelicula);

--Agregar llave primaria (ahora si)
alter table pelicula add constraint pkpelicula primary key(titulo,año);

--Cambiar el nombre de una tabla
alter table pelicula rename to movies;

--Cambiar el nombre de una columna
alter table movies rename column titulo to nombre;

--Cambiar el nombre de una restricción
alter table movies rename constraint pkpelicula to pkmovies;

--Agregar una columna a una tabla
alter table movies add column clasificacion char(5);
select * from movies;

--Actualizar el valor de una fila
update movies set pais = 'JAPÓN' where año = 2005 and nombre = 'King kong';

--Borrar una columna de una tabla;
alter table movies drop column clasificacion;

--INTEGRIDAD REFERENCIAL
--Volviendo a la tabla del cliente
create table cliente(
correo varchar(100),
nombre varchar(100),
paterno varchar(100),
materno varchar(100),
direccion varchar(10),
fecha date--,
--constraint pkcliente primary key(correo)
);

--Agregar la restricción de llave primaria
alter table cliente add constraint pkcliente primary key(correo);

--Insertar un cliente
insert into cliente values('juan@gmail.com.mx','JUAN MANUEL','PÉREZ','RÍOS',
						   'FAISANES 43 EDOMEX','1985-04-26');
						   
--Modificar el tamaño y/o tipo de dato de una columna
alter table cliente alter column direccion set data type varchar(100);

select * from cliente;

--Estas modificaciones solo son posibles si no entran en conflicto con los datos insertados
alter table cliente alter column nombre set data type varchar(10);

--Como se observa, salvo la llave primaria, todos los atributos son opcionales
insert into cliente(correo,nombre,paterno,materno,direccion) 
values('patyhs@gmail.com.mx','PATRICIA','HERNÁNDEZ','SÁNCHEZ','BUGAMBILIAS 85 CDMX');

--Indicar que un campo es obligatorio, añadir restricción not null
alter table cliente alter column fecha set not null;

--Corrigiendo el problema
update cliente set fecha = '1979-12-23' where correo = 'patyhs@gmail.com.mx';

--Probando la restricción
insert into cliente values('laurafg@gmail.com','LAURA','FRÍAS','GONZÁLEZ',
						   'FRESNOS 95 OAXACA');
--Corrigiendo
insert into cliente values('laurafg@gmail.com','LAURA','FRÍAS','GONZÁLEZ',
						   'FRESNOS 95 OAXACA','1990-08-15');
select * from cliente;
--¿Qué pasa cuando no nos mandan un valor y no queremos hacerlo obligatorio?
insert into cliente(correo,nombre,paterno,materno,fecha) 
values('anton96@gmail.com','ANTONIO','MNA','GERRERO','1990-09-15');

--Agregar una restriccion default
alter table cliente alter column direccion set default 'NO PROPORCIONADO';

--PROBANDO EL EFECTO
insert into cliente(correo,nombre,paterno,materno,fecha) 
values('rodo78@gmail.com','RODRIGO','SANTES','GÓMEZ','1989-10-25');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha) 
values('ximena87@gmail.com','XIMENA','ROBLES','CAMPOS','DURAZNOS 78 COLIMA','1990-09-15');
--Añadir restriccion default
select * from cliente;

--Problemas con el correo elecrtrónico
insert into cliente(correo,nombre,paterno,materno,fecha) 
values ('@gmail.com','AMPARO','SÁNCHEZ','MACÍAS','1995-02-18'); 
       
select * from cliente;

--Solución: añadir restriccion CHECK (siempre y cuando los correos cumplan)
alter table cliente add constraint mail check(correo like '_%@_%._%'); 

--Corregimos el problema
update cliente set correo = 'asm@gmail.com' where correo = '@gmail.com';

--Probamos la restricción
insert into cliente(correo,nombre,paterno,materno,fecha) 
values ('@gmail.com','SALVADOR','GARCÍA','PÉREZ','1975-09-28');

insert into cliente(correo,nombre,paterno,materno,fecha) 
values ('s@g.c','SALVADOR','GARCÍA','PÉREZ','1975-09-28');

select * from cliente;

--Actulizar más de un valor de una fila
update cliente set correo = 'antonio.mina@gmail.com',
                   paterno = 'MINA',
                   materno = 'GUERRERO',
                   direccion = 'TULIPANES 54 PUEBLA'
where correo = 'anton96@gmail.com';

--Hacer algunos atributos obligatorios
alter table cliente alter column paterno set not null;                 
alter table cliente alter column materno set not null;                 
alter table cliente alter column direccion set not null;

--Evitar que se registren clientes mayores de edad
alter table cliente add constraint mayoredad
   check(extract (years from age(current_date,fecha)) >= 18); 
select * from cliente
--Probando la restricción
insert into cliente 
values ('carlos@gmail.com','CARLOS','LARA','SÁNCHEZ','AV. UNIVERSIDAD 89 CDMX',current_date);

--Pedidos
create table pedidos(
numpedido serial,
fecha date not null,
correo varchar(100),
constraint pkpedido primary key(numpedido),
constraint fkpedido foreign key(correo) 
                references cliente(correo)
);
select * from cliente;
select * from pedidos;
insert into pedidos(correo,fecha) values ('juan@gmail.com.mx',current_date);
insert into pedidos(correo,fecha) values ('juan@gmail.com.mx',current_date);
insert into pedidos(correo,fecha) values ('patyhs@gmail.com.mx',current_date);

select * from pedidos;

--Intentemos actualiar el correo del cliente JUAN
update cliente set correo = 'juan.perez@gmail.com' where correo = 'juan@gmail.com.mx';

--Intentemos actualizar el correo de JUAN EN PEDIDOS
update pedidos set correo = 'juan.perez@gmail.com' where correo = 'juan@gmail.com.mx';

--Intentemos borrar al cliente JUAN
delete from cliente where correo = 'juan@gmail.com.mx'; --2.Borrar del lado de la llave PK

delete from pedidos where correo = 'juan@gmail.com.mx'; --1. Borrar del lado de la llave FK
select * from pedidos;
select * from cliente;
--Borremos la tabla pedidos
drop table pedidos;

--Vaciamos la tabla cliente;
truncate table cliente;

--Creamos las tablas
--Pedidos
create table pedidos(
numpedido serial,
fecha date not null,
correo varchar(100),
constraint pkpedido primary key(numpedido),
constraint fkpedido foreign key(correo) references cliente(correo)
on delete cascade on update cascade
);

--Articulo
create table articulo(
idarticulo serial,
nombre varchar(100) not null,
cantidad int not null,
precio numeric(7,2) not null,
constraint pkart primary key(idarticulo),
constraint cant check(cantidad >= 0),
constraint prec check(precio >= 0)
);

create table detalle(
nopedido int,
noart int,
cantidad int,
constraint fkdetalle1 foreign key(nopedido) references pedidos(numpedido)
on delete cascade on update cascade,
constraint fkdetalle2 foreign key(noart) references articulo(idarticulo)
on delete cascade on update cascade,                                                 
constraint mayor check(cantidad > 0)
);                      

--Para poblar la BD
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('gabriel@hotmail.com','GABRIEL','GONZÁLEZ','ARIAS','BLVD.BENITO JUAREZ Y MAGISTERIO S/N','20-07-1979');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('daniela@yahoo.com.mx','DANIELA','LOPEZ','ACOSTA','CALZ SANDERS (CTO COMER SORIANA) S/N','13-02-1981');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('jesus@hotmail.com','JOSE DE JESUS','SANCHEZ','PARRA','JUAREZ 84 P.B.','10-08-1978');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('dario@yahoo.com.mx','DARIO EMMANUEL','PÉREZ','SOSA','PRESIDENTE MAZARIK','02-01-1979');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('jorgeantonio@hotmail.com','JORGE ANTONIO','DÍAZ','FIGUEROA','PLAZA PRINCIPAL','25-09-1980');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('yair@yahoo.com.mx','YAIR NAHUM','GÓMEZ','SUÁREZ','AV. INSTITUTO POLITECNICO NACIONAL','17-11-1975');
insert into cliente(correo,nombre,paterno,materno,direccion,fecha)
        values('luisabraham@hotmail.com','LUIS ABRAHAM','TORRES','VERA','ARTEAGA NO. 78','08-03-1979');

--Para la tabla pedido
insert into pedidos(fecha,correo) values('10/1/2012','gabriel@hotmail.com');
insert into pedidos(fecha,correo) values('12/1/2020','daniela@yahoo.com.mx');
insert into pedidos(fecha,correo) values('22/1/2020','jesus@hotmail.com');
insert into pedidos(fecha,correo) values('1/2/2020','dario@yahoo.com.mx');
insert into pedidos(fecha,correo) values('11/2/2020','jorgeantonio@hotmail.com');
insert into pedidos(fecha,correo) values('21/2/2020','yair@yahoo.com.mx');
insert into pedidos(fecha,correo) values('2/3/2020','luisabraham@hotmail.com');
insert into pedidos(fecha,correo) values('12/3/2020','dario@yahoo.com.mx');
insert into pedidos(fecha,correo) values('22/3/2020','gabriel@hotmail.com');
insert into pedidos(fecha,correo) values('1/4/2020','daniela@yahoo.com.mx');
insert into pedidos(fecha,correo) values('11/4/2020','yair@yahoo.com.mx');
insert into pedidos(fecha,correo) values('21/4/2020','luisabraham@hotmail.com');
insert into pedidos(fecha,correo) values('1/5/2020','dario@yahoo.com.mx');
insert into pedidos(fecha,correo) values('11/5/2020','daniela@yahoo.com.mx');
insert into pedidos(fecha,correo) values('21/5/2020','gabriel@hotmail.com');
insert into pedidos(fecha,correo) values('31/5/2020','luisabraham@hotmail.com');

--Para la tabla de articulo
insert into articulo(nombre,cantidad,precio) values('Switch 8 puertos',100,600);
insert into articulo(nombre,cantidad,precio) values('Dlink 56K',700,100);
insert into articulo(nombre,cantidad,precio) values('Monitor Samsung 17',100,2500);
insert into articulo(nombre,cantidad,precio) values('RAM DDR2 512/533',100,300);
insert into articulo(nombre,cantidad,precio) values('Tarjeta NVIDIA FX',100,800);
insert into articulo(nombre,cantidad,precio) values('Procesador Pentium4',100,2000);
insert into articulo(nombre,cantidad,precio) values('Switch 12 puertos',100,1000);
insert into articulo(nombre,cantidad,precio) values('Dlink 56K',100,800);
insert into articulo(nombre,cantidad,precio) values('Monitor Samsung 14',100,2000);
insert into articulo(nombre,cantidad,precio) values('RAM DDR2 1024/533',100,600);
insert into articulo(nombre,cantidad,precio) values('Tarjeta NVIDIA FX 5200',100,1000);
insert into articulo(nombre,cantidad,precio) values('Procesador Pentium Celeron',100,1600);

--Para la tabla detalle
insert into detalle(nopedido,noart,cantidad) values(1,1,1);
insert into detalle(nopedido,noart,cantidad) values(1,2,1);
insert into detalle(nopedido,noart,cantidad) values(1,3,1);
insert into detalle(nopedido,noart,cantidad) values(1,11,3);
insert into detalle(nopedido,noart,cantidad) values(2,3,1);
insert into detalle(nopedido,noart,cantidad) values(2,4,1);
insert into detalle(nopedido,noart,cantidad) values(3,6,1);
insert into detalle(nopedido,noart,cantidad) values(3,7,1);
insert into detalle(nopedido,noart,cantidad) values(3,8,2);
insert into detalle(nopedido,noart,cantidad) values(4,9,2);
insert into detalle(nopedido,noart,cantidad) values(4,10,2);
insert into detalle(nopedido,noart,cantidad) values(4,11,3);
insert into detalle(nopedido,noart,cantidad) values(5,12,2);
insert into detalle(nopedido,noart,cantidad) values(5,3,3);
insert into detalle(nopedido,noart,cantidad) values(6,4,2);
insert into detalle(nopedido,noart,cantidad) values(6,8,2);
insert into detalle(nopedido,noart,cantidad) values(7,9,2);
insert into detalle(nopedido,noart,cantidad) values(7,10,3);
insert into detalle(nopedido,noart,cantidad) values(8,11,3);
insert into detalle(nopedido,noart,cantidad) values(8,12,3);
insert into detalle(nopedido,noart,cantidad) values(8,1,3);
insert into detalle(nopedido,noart,cantidad) values(9,2,2);
insert into detalle(nopedido,noart,cantidad) values(9,5,1);
insert into detalle(nopedido,noart,cantidad) values(9,6,1);
insert into detalle(nopedido,noart,cantidad) values(9,8,3);
insert into detalle(nopedido,noart,cantidad) values(10,9,1);
insert into detalle(nopedido,noart,cantidad) values(11,10,3);
insert into detalle(nopedido,noart,cantidad) values(11,12,3);
insert into detalle(nopedido,noart,cantidad) values(12,11,3);
insert into detalle(nopedido,noart,cantidad) values(12,6,1);
insert into detalle(nopedido,noart,cantidad) values(13,3,1);
insert into detalle(nopedido,noart,cantidad) values(13,2,1);
insert into detalle(nopedido,noart,cantidad) values(14,1,1);
insert into detalle(nopedido,noart,cantidad) values(14,8,1);
insert into detalle(nopedido,noart,cantidad) values(15,9,1);
insert into detalle(nopedido,noart,cantidad) values(15,6,2);
insert into detalle(nopedido,noart,cantidad) values(15,5,2);
insert into detalle(nopedido,noart,cantidad) values(16,1,2);
insert into detalle(nopedido,noart,cantidad) values(16,11,2);
insert into detalle(nopedido,noart,cantidad) values(16,12,3);                                                                                              

select * from cliente;
select * from articulo;
select * from pedidos;
select * from detalle;

--Integridad referencial, mantenimiento de llaves foráneas
--Politica por omision
delete from articulo where idarticulo = 3;

select * from detalle where noart = 3;

--Para lograrlo, primero debemos borrar en la tabla donde está la llave foránea
delete from detalle where noart = 3;

--Ahora si podemos borrar (muy tedioso)
delete from articulo where idarticulo = 3;

--Actualizando el articulo 1
update articulo set idarticulo = 20 where idarticulo = 1;

select * from detalle where noart = 1;

--Intentar actualizar del lado de detalle
update detalle set noart = 20 where noart = 1;

--Retiramos momentáneamente las restricciones de FK
alter table pedidos drop constraint fkpedido;
alter table detalle drop constraint fkdetalle1;
alter table detalle drop constraint fkdetalle2;

--Politica de establecimiento de nulos
alter table pedidos add constraint fkpedido foreign key(correo) references cliente(correo)
on update set null on delete set null;
	
alter table detalle add constraint fkdetalle1 foreign key(nopedido) references pedidos(numpedido)
on update set null on delete set null;

alter table detalle add constraint fkdetalle2 foreign key(noart) references articulo(idarticulo)
on update set null on delete set null;

select * from cliente;
select * from pedidos where correo = 'gabriel@hotmail.com';

--Borramos al cliente GABRIEL
delete from cliente where correo = 'gabriel@hotmail.com';   
select * from pedidos where correo = 'gabriel@hotmail.com'; --Consistencia
select * from pedidos; --Efecto indeseable

--Veamos que sucede con la actualización
select * from cliente where correo = 'daniela@yahoo.com.mx';
select * from pedidos where correo = 'daniela@yahoo.com.mx';

update cliente set correo = 'dany@gmail.com' where correo = 'daniela@yahoo.com.mx';

--Verificamos
select * from cliente where correo = 'daniela@yahoo.com.mx'; 
select * from cliente where correo = 'dany@gmail.com';

--Actualizar el correo
update cliente set correo = 'dany@gmail.com' where correo = 'daniela@yahoo.com.mx';

select * from pedidos where correo = 'daniela@yahoo.com.mx';
select * from pedidos where correo = 'dany@gmail.com';
select * from pedidos; --Efecto indeseable

--Retiramos los nulos
delete from pedidos where correo is null;

--Retiramos momentáneamente las restricciones de FK
alter table pedidos drop constraint fkpedido;
alter table detalle drop constraint fkdetalle1;
alter table detalle drop constraint fkdetalle2;

--Politica en Cascada
alter table pedidos add constraint fkpedido foreign key(correo) references cliente(correo)
on update cascade on delete cascade;
	
alter table detalle add constraint fkdetalle1 foreign key(nopedido) references pedidos(numpedido)
on update cascade on delete cascade;

alter table detalle add constraint fkdetalle2 foreign key(noart) references articulo(idarticulo)
on update cascade on delete cascade;

--Probamos
select * from cliente

--Actualizamos al cliente DARIO
update cliente set correo = 'dario@hotmail.com' where correo = 'dario@yahoo.com.mx';

select * from cliente where correo = 'dario@hotmail.com';
select * from pedidos where correo = 'dario@hotmail.com';

--En el caso del borrado
select * from cliente where correo = 'jesus@hotmail.com';
select * from pedidos where correo = 'jesus@hotmail.com';

delete from cliente where correo = 'jesus@hotmail.com';

select * from cliente where correo = 'jesus@hotmail.com';
select * from pedidos where correo = 'jesus@hotmail.com';
select * from pedidos;
